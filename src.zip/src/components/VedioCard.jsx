import React from 'react'

function VedioCard() {
  return (
    <div>VedioCard</div>
  )
}

export default VedioCard